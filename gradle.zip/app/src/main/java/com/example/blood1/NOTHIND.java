package com.example.blood1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NOTHIND extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_n_o_t_h_i_n_d);
    }
}